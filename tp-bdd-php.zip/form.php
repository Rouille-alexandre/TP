<!DOCTYPE HTML>
<html>
  <meta charset="utf-8" />
	<body>
 

		<?php

		$nom = $_GET["nom"];
		$prenom = $_GET["prenom"];
		$tel = $_GET["tel"];
	
		
		
	
				echo "Vous avez bien ete inscrit ! <br><br>";
		
				echo "Nom : ",$nom,"<br><br>";
				
				echo "Prenom : ",$prenom,"<br><br>";
				
				echo "Telephone : ",$tel;
				
		
		
		echo"<br><br> <input type=button onclick=window.location.href='index.html'; value=Retour> <br><br> ";
	
	ini_set('display_errors', 'on');

    $serveur='localhost';
    $db='etudiant';
    $utilisateur='root';
    $mdp='';
	
	
	
	try{	
		 $connextion = new PDO("mysql:host=$serveur;dbname=$db",$utilisateur,$mdp);
		if($connextion) echo'connextion a la BDD reussie ! ';
	   }
	catch(PDOException $event)
	{
	 die('erreur : ' .$event->getMessage());
	}
	
	
	

		
	$inserer="INSERT INTO etudiant(nom, prenom, telephone ) VALUES ('$nom','$prenom','$tel')";
	
	$inserer=$connextion->exec($inserer);
	
	
	//$modifier= "UPDATE etudiants SET nom='$nom',prenom='$prenom',telephone='$tel' WHERE idetudiants =0";
	//$modifier=$connextion->exec($modifier);
	
	//if($modifier) echo '<br> Modif faites';
	//else
	//{
		//$table_error=$connextion->errorInfo();
		//echo '<br> Erreur : $table_error';
	//}

		?>
	</body>
</html>

