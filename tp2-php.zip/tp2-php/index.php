<!--ROUILLE Alexandre BTS SN2  |  --> 

<html>

	<head> <title>TP2 PHP</title> </head>
	<link rel="styleshett" type="text/css" href="style.css">
	<body>
	
	<?php include 'haut.php'; ?>
	<?php include 'menu.php'; ?>
	<?php include 'body.php'; ?>
	<?php include 'bas.php'; ?>


	
	
	</body>
	
</html>