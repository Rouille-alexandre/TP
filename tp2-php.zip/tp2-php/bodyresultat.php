<!--ROUILLE Alexandre BTS SN2  |  --> 

<html>

	<head> <title>TP2 PHP</title> </head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<body>
	 
		
		<div id="graph">
		<?php echo '<img src="./graph.php/>' ;?>
		</div>
		

	</div>
	
	</body>
	
	
	</html>