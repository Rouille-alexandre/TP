<!--ROUILLE Alexandre BTS SN2  |  --> 

<html>

	<head> <title>TP2 PHP</title> </head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<body>
	 
		<div id="centre">
			<div id="formu">

	    	<form action="phps.php" method="get">
			
				<label for="profs">Choix du Professeur : </label>

				<select name="professeur" id="professeur">
					<option>Choisir un professeur
					<option>M.GIROD
					<option>Made. ACOSTINELLI
					<option>Made. DONNE
					<option>Made. VOGLER
				
				</select><br><br>
				
				
				<label for="cours">Choix du Professeur : </label>

				<select name="cour" id="cour">
					<option>Choisir un cours
					<option >Cours d'Anglais
					<option>Cours de francais
					<option>Cours de HardWare
					<option>Cours de SoftWare
					<option>FLASH
			
				</select> <br><br>
				
				    <label for="nombre">Nombre de seances de cours a commander:</label>
					<input type="text" id="nb" name="nb" />
					
					<br><br> 
			
			
	
	        <button type="submit">Soumettre</button>
		
			<form>
		
			</div>

	</div>
	
	</body>