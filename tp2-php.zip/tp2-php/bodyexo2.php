<!--ROUILLE Alexandre BTS SN2  |  --> 

<html>

	<head> <title>TP2 PHP</title> </head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<body>
	 
		<div id="centre">
			<div id="formu">

	    	<form action="phpsexo2.php" method="get">

				    <label for="nombre">Nom: </label>
					<input type="text" id="nom" name="nom" />
					
					<br><br> 
					
					 <label for="age">Age: </label>
					<input type="text" id="age" name="age" />
					
					<br><br> 
					
					 <label for="mail">Mail: </label>
					<input type="text" id="mail" name="mail" />
					
					<br><br> 
					
					<label for="don">Don: </label>
					<input type="text" id="don" name="don" />
					
					<br><br> 
			
			
			
	        <button type="submit">Soumettre</button>
			
			<br><br> <input type=button onclick=window.location.href='resultat.php'; value=Resultat>
		
			<form>
		
			</div>

	</div>
	
	</body>
	
	
	</html>